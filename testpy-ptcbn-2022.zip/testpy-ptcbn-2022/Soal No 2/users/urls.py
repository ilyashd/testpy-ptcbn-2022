from django.urls import path
from . import views
from .views import CurrentUserAPIView



urlpatterns = [
    path('api/auth/login', views.login),
    path('api/auth/user', CurrentUserAPIView.as_view(), name='current-user'),
]